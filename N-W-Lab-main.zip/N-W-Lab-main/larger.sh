echo "Enter two number"
read a b
if [ $a -gt $b ]
then
echo "$a is largest"
else
echo "$b is largest"
fi
