soupu is a pretty girl
pavi is sweetty girl
revu is a good girl
blessy is a mad girl
abi is a fantastic girl
