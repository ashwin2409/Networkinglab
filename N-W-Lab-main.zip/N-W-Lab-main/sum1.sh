hello
hai
welcome
hyy
kii
gjhh
wf
welcome to my place
welcome to ootty
 hey elcome
hwy welcome
