echo -n Enter the name:
read p
echo -n Enter the roll number:
read q
echo -n Enter email id:
read r
echo "Name:$p"
echo "Rollnumber:$q"
echo "Emailid:$r"
