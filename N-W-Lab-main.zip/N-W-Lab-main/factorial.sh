echo Enter the number
read n
j=1
while [$j -le $n]
do
f=1

