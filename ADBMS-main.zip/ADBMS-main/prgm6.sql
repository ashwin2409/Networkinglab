declare
x char(1):='&x';
begin
if(x>='a' and x<='z') or (x>='a' and x<='z')then
dbms_output.put_line('This is a letter');
else
dbms_output.put_line('This is not a letter');
if x between '0' and '9' then
dbms_output.put_line('This is a number');
else
dbms_output.put_line('not a number');
end if;
end if;
end;
