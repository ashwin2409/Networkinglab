declare
a number:=15;
b number:=20;
c number;
begin
c:=a+b;
dbms_output.put_line('Sum is'||c);
end;