create or replace procedure pr3(currency in out number)is
begin
currency:=currency*82;
end;
