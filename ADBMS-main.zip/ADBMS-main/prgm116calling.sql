declare
currency number:=&currency;
begin
pr3(currency);
dbms_output.put_line(currency);
end;