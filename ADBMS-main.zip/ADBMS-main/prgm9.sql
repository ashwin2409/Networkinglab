declare
a number;
begin
for a in 1..10
loop
dbms_output.put_line(a);
end loop;
end;