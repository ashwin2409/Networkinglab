package org.calc;
public class Multiply{
private int x,y;
public Multiply(int a,int b){
x=a;y=b;
}
public int mul(){
return (x*y);
}
}
