package org.calc;
public class Divide{
private int x,y;
public Divide(int a,int b){
x=a;y=b;
}
public int div(){
return (x/y);
}
}
