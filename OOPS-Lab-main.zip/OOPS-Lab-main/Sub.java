package org.calc;
public class Sub{
private int x,y;
public Sub(int a,int b){
x=a;y=b;
}
public int sub(){
return (x-y);
}
}
