package org.calc;
public class Add{
private int x,y;
public Add(int a,int b){
x=a;y=b;
}
public int add(){
return(x+y);
}
}